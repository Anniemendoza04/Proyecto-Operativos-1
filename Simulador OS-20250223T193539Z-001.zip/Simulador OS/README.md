# SimuladorOS

## Overview
SimuladorOS is a simulation tool designed to model and visualize the performance of an operating system. It allows users to create and manage processes, apply different scheduling algorithms, and observe the system's behavior under various configurations.

## Features
- **Process Management**: Create, execute, and manage processes with different states (ready, blocked, running).
- **Scheduling Algorithms**: Implement various scheduling strategies including FCFS, SJF, Round Robin, SRT, and Feedback.
- **Performance Visualization**: Graphical representation of system performance over time and individual CPU performance.
- **User Interface**: An intuitive graphical user interface for easy interaction with the simulator.

## File Structure
- **src/**
  - **Estadistica.java**: Collects and processes statistical data related to system performance.
  - **InterfazSimulacion.java**: Provides the graphical user interface for user interaction.
  - **Proceso.java**: Represents a process in the simulation with properties and execution management.
  - **SimuladorOS.java**: Main logic for the simulator, managing CPU and process scheduling.
  - **Planificador.java**: Implements various scheduling algorithms.
  - **Cola.java**: Represents a queue for managing processes.
  - **CPU.java**: Represents a CPU and tracks performance metrics.
  - **Nodo.java**: Used as a node in linked data structures.
  - **types/index.java**: Exports various types and interfaces for better code organization.
  - **graphs/**
    - **GraphPanel.java**: Renders graphs in the user interface.
    - **PerformanceGraph.java**: Creates and updates performance graphs based on system data.
    - **CPUPerformanceGraph.java**: Tracks and visualizes individual CPU performance.

## Installation
1. Clone the repository:
   ```
   git clone <repository-url>
   ```
2. Navigate to the project directory:
   ```
   cd SimuladorOS
   ```
3. Install dependencies:
   ```
   npm install
   ```

## Usage
1. Run the simulator:
   ```
   java -jar SimuladorOS.jar
   ```
2. Use the graphical interface to create processes, select scheduling algorithms, and visualize performance metrics.

## Contributing
Contributions are welcome! Please submit a pull request or open an issue for any enhancements or bug fixes.

## License
This project is licensed under the MIT License. See the LICENSE file for details.