import java.util.List;

public class Types {
    public interface PerformanceData {
        long getTimestamp();
        double getCpuUsage();
        double getMemoryUsage();
    }

    public interface ProcessData {
        int getId();
        String getName();
        Proceso.STATUS getStatus();
        int getExecutionTime();
    }

    public interface SimulationConfig {
        int getNumProcessors();
        long getCycleDuration();
        Planificador.AlgoritmoPlanificacion getSchedulingAlgorithm();
    }

    public interface Graphable {
        void updateGraph(List<PerformanceData> data);
    }
}