import javax.swing.*;
import java.awt.*;
import java.util.List;

public class CPUPerformanceGraph extends JPanel {
    private List<Double> cpuUsageData;
    private int maxDataPoints;

    public CPUPerformanceGraph(int maxDataPoints) {
        this.maxDataPoints = maxDataPoints;
        this.cpuUsageData = new ArrayList<>();
        setPreferredSize(new Dimension(800, 400));
    }

    public void updateCPUUsage(double usage) {
        if (cpuUsageData.size() >= maxDataPoints) {
            cpuUsageData.remove(0);
        }
        cpuUsageData.add(usage);
        repaint();
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        drawGraph(g);
    }

    private void drawGraph(Graphics g) {
        int width = getWidth();
        int height = getHeight();
        int padding = 20;
        int graphWidth = width - 2 * padding;
        int graphHeight = height - 2 * padding;

        g.drawRect(padding, padding, graphWidth, graphHeight);
        g.drawString("CPU Performance Over Time", width / 2 - 50, padding - 5);

        if (cpuUsageData.isEmpty()) {
            return;
        }

        double maxUsage = cpuUsageData.stream().max(Double::compare).orElse(0.0);
        double scaleY = graphHeight / maxUsage;

        for (int i = 1; i < cpuUsageData.size(); i++) {
            int x1 = padding + (i - 1) * graphWidth / (maxDataPoints - 1);
            int y1 = height - padding - (int) (cpuUsageData.get(i - 1) * scaleY);
            int x2 = padding + i * graphWidth / (maxDataPoints - 1);
            int y2 = height - padding - (int) (cpuUsageData.get(i) * scaleY);
            g.drawLine(x1, y1, x2, y2);
        }
    }
}