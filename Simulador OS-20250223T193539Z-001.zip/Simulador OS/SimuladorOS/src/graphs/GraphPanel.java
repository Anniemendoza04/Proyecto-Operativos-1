import javax.swing.*;
import java.awt.*;
import java.util.List;

public class GraphPanel extends JPanel {
    private PerformanceGraph performanceGraph;
    private CPUPerformanceGraph cpuPerformanceGraph;

    public GraphPanel() {
        setLayout(new BorderLayout());
        performanceGraph = new PerformanceGraph();
        cpuPerformanceGraph = new CPUPerformanceGraph();

        add(performanceGraph, BorderLayout.CENTER);
        add(cpuPerformanceGraph, BorderLayout.SOUTH);
    }

    public void updateGraphs(List<Double> performanceData, List<Double> cpuData) {
        performanceGraph.updateData(performanceData);
        cpuPerformanceGraph.updateData(cpuData);
        repaint();
    }
}