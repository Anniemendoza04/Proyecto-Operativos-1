public class Cola {
    private Nodo frente;
    private Nodo atras;
    private int tamaño;

    public Cola() {
        this.frente = null;
        this.atras = null;
        this.tamaño = 0;
    }

    public boolean estaVacia() {
        return tamaño == 0;
    }

    public void encolar(Proceso proceso) {
        Nodo nuevoNodo = new Nodo(proceso);
        if (estaVacia()) {
            frente = nuevoNodo;
        } else {
            atras.setSiguiente(nuevoNodo);
        }
        atras = nuevoNodo;
        tamaño++;
    }

    public Proceso desencolar() {
        if (estaVacia()) {
            return null;
        }
        Proceso proceso = frente.getProceso();
        frente = frente.getSiguiente();
        tamaño--;
        if (estaVacia()) {
            atras = null;
        }
        return proceso;
    }

    public Proceso getFrente() {
        return estaVacia() ? null : frente.getProceso();
    }

    public int getTamaño() {
        return tamaño;
    }

    public List<Proceso> toList() {
        List<Proceso> lista = new ArrayList<>();
        Nodo actual = frente;
        while (actual != null) {
            lista.add(actual.getProceso());
            actual = actual.getSiguiente();
        }
        return lista;
    }
}