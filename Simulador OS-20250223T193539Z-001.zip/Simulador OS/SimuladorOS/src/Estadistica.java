public class Estadistica {
    private int totalCiclos;
    private int totalProcesos;
    private int procesosCompletados;
    private long tiempoTotalEjecucion;
    private long tiempoBloqueado;
    private long tiempoListo;

    public Estadistica() {
        this.totalCiclos = 0;
        this.totalProcesos = 0;
        this.procesosCompletados = 0;
        this.tiempoTotalEjecucion = 0;
        this.tiempoBloqueado = 0;
        this.tiempoListo = 0;
    }

    public void registrarCiclo() {
        totalCiclos++;
    }

    public void registrarProcesoCompletado() {
        procesosCompletados++;
    }

    public void agregarTiempoEjecucion(long tiempo) {
        tiempoTotalEjecucion += tiempo;
    }

    public void agregarTiempoBloqueado(long tiempo) {
        tiempoBloqueado += tiempo;
    }

    public void agregarTiempoListo(long tiempo) {
        tiempoListo += tiempo;
    }

    public double calcularEficiencia() {
        if (totalCiclos == 0) return 0;
        return (double) procesosCompletados / totalCiclos * 100;
    }

    public int getTotalCiclos() {
        return totalCiclos;
    }

    public int getTotalProcesos() {
        return totalProcesos;
    }

    public int getProcesosCompletados() {
        return procesosCompletados;
    }

    public long getTiempoTotalEjecucion() {
        return tiempoTotalEjecucion;
    }

    public long getTiempoBloqueado() {
        return tiempoBloqueado;
    }

    public long getTiempoListo() {
        return tiempoListo;
    }

    public void setTotalProcesos(int totalProcesos) {
        this.totalProcesos = totalProcesos;
    }
}