public class CPU {
    private int id;
    private Proceso procesoEjecutando;
    private int ciclosEjecutados;

    public CPU(int id) {
        this.id = id;
        this.ciclosEjecutados = 0;
    }

    public void ejecutarProceso(Proceso proceso) {
        this.procesoEjecutando = proceso;
        // Simulate process execution
        while (proceso.getPc() < proceso.getNumInstrucciones()) {
            proceso.incrementarCiclosEjecutados();
            ciclosEjecutados++;
            proceso.setPc(proceso.getPc() + 1);
            try {
                Thread.sleep(100); // Simulate time taken to execute an instruction
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
        proceso.setEstado(Proceso.STATUS.READY); // Change state to READY when done
        this.procesoEjecutando = null; // Clear the executing process
    }

    public Proceso getProcesoEjecutando() {
        return procesoEjecutando;
    }

    public int getCiclosEjecutados() {
        return ciclosEjecutados;
    }

    public int getId() {
        return id;
    }

    @Override
    public String toString() {
        return "CPU{" +
                "id=" + id +
                ", procesoEjecutando=" + (procesoEjecutando != null ? procesoEjecutando.getNombre() : "Ninguno") +
                ", ciclosEjecutados=" + ciclosEjecutados +
                '}';
    }
}