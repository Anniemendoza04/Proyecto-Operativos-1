import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Random;
import java.util.List;
import java.util.ArrayList;
import java.util.stream.Collectors;

class InterfazSimulacion extends javax.swing.JFrame {

    private SimuladorOS simulacion;
    private final Random rand = new Random();

    private JList<Proceso> listListos;
    private JList<Proceso> listBloqueados;
    private JList<Proceso> listRunning;
    private JList<String>[] listPrioridades; 
    private JPanel[] panelPrioridades;
    private GraphPanel graphPanel;

    public InterfazSimulacion() {
        initComponents();
        this.simulacion = new SimuladorOS(5, 5, Planificador.AlgoritmoPlanificacion.RoundRobin);
    
        listListos = new JList<>(new DefaultListModel<>());
        listBloqueados = new JList<>(new DefaultListModel<>());
        listRunning = new JList<>(new DefaultListModel<>());
        listPrioridades = new JList[5];
        panelPrioridades = new JPanel[5];

        listListos.setCellRenderer(new ProcesoListCellRenderer());
        listBloqueados.setCellRenderer(new ProcesoListCellRenderer());
        listRunning.setCellRenderer(new ProcesoListCellRenderer());
        
        jPanelListos.add(new JScrollPane(listListos), BorderLayout.CENTER);
        jPanelBloqueados.add(new JScrollPane(listBloqueados), BorderLayout.CENTER);
        jPanelCulminados.add(new JScrollPane(listRunning), BorderLayout.CENTER);
    
        JPanel panelPrioridadesContainer = new JPanel(new GridLayout(5, 1));
        for (int i = 0; i < 5; i++) {
            listPrioridades[i] = new JList<>(new DefaultListModel<>());
            panelPrioridades[i] = new JPanel();
            panelPrioridades[i].add(new JScrollPane(listPrioridades[i]));
            panelPrioridadesContainer.add(panelPrioridades[i]);
        }
        jPanelCulminados.add(panelPrioridadesContainer, BorderLayout.SOUTH);

        graphPanel = new GraphPanel();
        add(graphPanel, BorderLayout.SOUTH);
    }

    @SuppressWarnings("unchecked")
    private void initComponents() {
        jLabel10 = new javax.swing.JLabel();
        jLabelClock = new javax.swing.JLabel();
        jPanel1 = new javax.swing.JPanel();
        jLabel4 = new javax.swing.JLabel();
        jButtonCrearProceso = new javax.swing.JButton();
        jLabel5 = new javax.swing.JLabel();
        jSpinnerGenExecpcion = new javax.swing.JSpinner();
        jLabel8 = new javax.swing.JLabel();
        jSpinnerCantInstrucciones = new javax.swing.JSpinner();
        jLabel7 = new javax.swing.JLabel();
        jSpinnerSatisfyExcep = new javax.swing.JSpinner();
        jLabel6 = new javax.swing.JLabel();
        jTextFieldProcessName = new javax.swing.JTextField();
        jToggleButtonProcessType = new javax.swing.JToggleButton();
        jLabel12 = new javax.swing.JLabel();
        jPanel2 = new javax.swing.JPanel();
        jLabel9 = new javax.swing.JLabel();
        jComboBoxPlanificacion = new javax.swing.JComboBox<>();
        jButtonCambiarProceso = new javax.swing.JButton();
        jPanel3 = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        jPanelListos = new javax.swing.JPanel();
        jPanelBloqueados = new javax.swing.JPanel();
        jPanelCulminados = new javax.swing.JPanel();
        jLabel3 = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        jButtonStartSim = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setBackground(new java.awt.Color(0, 0, 255));

        jLabel10.setText("Ciclo del Reloj");
        jLabelClock.setText("0");

        jPanel1.setBackground(new java.awt.Color(204, 204, 204));
    
        jLabel4.setText("Nombre de Proceso:");
    
        jButtonCrearProceso.setText("Crear Proceso");
        jButtonCrearProceso.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonCrearProcesoActionPerformed(evt);
            }
        });

        jLabel5.setText("Cantidad de Intrucciones:");
    
        jLabel8.setText("Cantidad de Ciclos para Satisfacer Excepcion:");
    
        jLabel7.setText("Cantidad de Ciclos para Excepcion:");
    
        jLabel6.setText("Tipo de Proceso:");
    
        jToggleButtonProcessType.setText("Cpu Bound");
    
        jLabel12.setText("I/O bound no select");
    
        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jSpinnerSatisfyExcep, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel7)
                    .addComponent(jLabel4)
                    .addComponent(jTextFieldProcessName, javax.swing.GroupLayout.PREFERRED_SIZE, 181, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel5)
                    .addComponent(jSpinnerCantInstrucciones, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jLabel6)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jLabel12))
                    .addComponent(jLabel8)
                    .addComponent(jSpinnerGenExecpcion, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(51, 51, 51)
                        .addComponent(jButtonCrearProceso))
                    .addComponent(jToggleButtonProcessType, javax.swing.GroupLayout.PREFERRED_SIZE, 111, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel4)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jTextFieldProcessName, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jLabel5)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jSpinnerCantInstrucciones, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel6)
                    .addComponent(jLabel12))
                .addGap(11, 11, 11)
                .addComponent(jToggleButtonProcessType)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jLabel7)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jSpinnerGenExecpcion, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jLabel8)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jSpinnerSatisfyExcep, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jButtonCrearProceso)
                .addContainerGap())
        );
    
        jPanel2.setBackground(new java.awt.Color(204, 204, 204));
    
        jLabel9.setText("Política de Planificación:");
    
        jComboBoxPlanificacion.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "FCFS", "SJF", "RoundRobin", "SRT", "Feedback" }));
        jComboBoxPlanificacion.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jComboBoxPlanificacionActionPerformed(evt);
            }
        });
    
        jButtonCambiarProceso.setText("Cambiar");
    }

    private void jButtonCrearProcesoActionPerformed(ActionEvent evt) {
        // Logic to create a new process and update the simulation
    }

    private void jComboBoxPlanificacionActionPerformed(ActionEvent evt) {
        // Logic to change scheduling algorithm
    }
    
    private void jButtonCambiarProcesoActionPerformed(ActionEvent evt) {
        // Logic to change the selected process
    }
    
    private void jButtonStartSimActionPerformed(ActionEvent evt) {
        // Logic to start the simulation
    }
    
    public void updateTimeLabel(SimuladorOS sim) {
        // Logic to update the time label based on the simulation state
    }

    public static void main(String args[]) {
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new InterfazSimulacion().setVisible(true);
            }
        });
    }
}