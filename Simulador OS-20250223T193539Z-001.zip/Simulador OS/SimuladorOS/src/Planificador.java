public class Planificador {
    public enum AlgoritmoPlanificacion {
        FCFS, SJF, ROUND_ROBIN, SRT, FEEDBACK
    }

    private AlgoritmoPlanificacion algoritmoActual;
    private SimuladorOS simulador;

    public Planificador(AlgoritmoPlanificacion algoritmo, SimuladorOS simulador) {
        this.algoritmoActual = algoritmo;
        this.simulador = simulador;
    }

    public void cambiarAlgoritmo(AlgoritmoPlanificacion nuevoAlgoritmo) {
        this.algoritmoActual = nuevoAlgoritmo;
    }

    public AlgoritmoPlanificacion getAlgoritmoActual() {
        return algoritmoActual;
    }

    public void planificar() {
        switch (algoritmoActual) {
            case FCFS:
                planificarFCFS();
                break;
            case SJF:
                planificarSJF();
                break;
            case ROUND_ROBIN:
                planificarRoundRobin();
                break;
            case SRT:
                planificarSRT();
                break;
            case FEEDBACK:
                planificarFeedback();
                break;
        }
    }

    private void planificarFCFS() {
        // Implementación del algoritmo FCFS
    }

    private void planificarSJF() {
        // Implementación del algoritmo SJF
    }

    private void planificarRoundRobin() {
        // Implementación del algoritmo Round Robin
    }

    private void planificarSRT() {
        // Implementación del algoritmo SRT
    }

    private void planificarFeedback() {
        // Implementación del algoritmo Feedback
    }
}