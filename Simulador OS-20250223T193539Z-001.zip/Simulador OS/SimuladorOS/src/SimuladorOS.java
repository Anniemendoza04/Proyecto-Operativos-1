import java.util.concurrent.Semaphore;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JFrame;
import graphs.GraphPanel;

public class SimuladorOS {
    private CPU[] cpus;
    private Cola colaListos;
    private Cola[] colasPrioridad;
    private Cola colaBloqueados;
    private Planificador planificador;
    private int cicloReloj = 0;
    private long duracionCiclo;
    private int numProcesadores;
    private String tipo;
    private Semaphore semaphore;
    private List<Cola> colasListos;
    private GraphPanel graphPanel; // Panel for displaying graphs

    public SimuladorOS(int numColasPrioridad, long duracionCiclo, Planificador.AlgoritmoPlanificacion algoritmoPlanificacion) {
        this(numColasPrioridad, 0, numColasPrioridad, duracionCiclo, algoritmoPlanificacion);
    }

    public SimuladorOS(int numColasPrioridad, int numColaListos, int numProcesadores, long duracionCiclo, Planificador.AlgoritmoPlanificacion algoritmoPlanificacion) {
        this.numProcesadores = numProcesadores;
        this.duracionCiclo = duracionCiclo;
        this.semaphore = new Semaphore(1);
        this.cpus = new CPU[numProcesadores];
        for (int i = 0; i < numProcesadores; i++) {
            cpus[i] = new CPU(i, semaphore);
            new Thread(cpus[i]).start();
        }
        this.colasPrioridad = new Cola[numColasPrioridad];
        for (int i = 0; i < colasPrioridad.length; i++) {
            colasPrioridad[i] = new Cola();
        }
        this.colaListos = new Cola();
        this.colaBloqueados = new Cola();
        this.planificador = new Planificador(algoritmoPlanificacion, this);
        this.tipo = "SISTEMA_OPERATIVO";
        this.colasListos = new ArrayList<>();
        this.colasListos.add(colaListos);
        this.graphPanel = new GraphPanel(); // Initialize the graph panel
    }

    public List<Proceso> getProcesos() {
        List<Proceso> procesos = new ArrayList<>();
        for (Cola cola : colasListos) {
            procesos.addAll(cola.toList());
        }
        return procesos;
    }

    public void planificarProcesos() {
        for (CPU cpu : cpus) {
            if (cpu.getProcesoEjecutando() == null && !colaListos.estaVacia()) {
                Proceso proceso = colaListos.desencolar();
                cpu.setProcesoEjecutando(proceso);
                proceso.setEstado(Proceso.STATUS.RUNNING);
            }

            if (cpu.getProcesoEjecutando() != null) {
                cpu.incrementarCiclos();
                Proceso proceso = cpu.getProcesoEjecutando();
                proceso.incrementarCiclosEjecutados();
            }
        }
        updateGraphs(); // Update graphs after planning processes
    }

    public void manejarExcepcionES(Proceso proceso) {
        proceso.setEstado(Proceso.STATUS.BLOCKED);
        colaBloqueados.encolar(proceso);
    }

    public void cambiarAlgoritmoPlanificacion(Planificador.AlgoritmoPlanificacion nuevoAlgoritmo) {
        this.planificador.cambiarAlgoritmo(nuevoAlgoritmo);
    }

    public void pruebaSRT() {
        Proceso proceso1 = new Proceso(1, "Proceso 1", Proceso.STATUS.READY, 0, 10, true, 0, 0, 5);
        proceso1.setTiempoLlegada(0);
        Proceso proceso2 = new Proceso(2, "Proceso 2", Proceso.STATUS.READY, 0, 20, true, 0, 0, 5);
        proceso2.setTiempoLlegada(1);
        Proceso proceso3 = new Proceso(3, "Proceso 3", Proceso.STATUS.READY, 0, 15, true, 0, 0, 5);
        proceso3.setTiempoLlegada(2);

        colaListos.encolar(proceso1);
        colaListos.encolar(proceso2);
        colaListos.encolar(proceso3);

        for (int i = 0; i < 30; i++) {
            planificarProcesos();
            incrementarCicloReloj();
            System.out.println("Ciclo de reloj: " + cicloReloj);
        }
    }

    public void incrementarCicloReloj() {
        this.cicloReloj++;
    }

    public void updateGraphs() {
        graphPanel.updatePerformanceData(cpus); // Update performance data for the graph
    }

    public static void main(String[] args) {
        SimuladorOS simulador = new SimuladorOS(2, 1000L, Planificador.AlgoritmoPlanificacion.SRT);
        JFrame frame = new JFrame("Simulador de Sistema Operativo");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.add(simulador.graphPanel); // Add the graph panel to the frame
        frame.setSize(800, 600);
        frame.setVisible(true);
        simulador.pruebaSRT();
    }
}