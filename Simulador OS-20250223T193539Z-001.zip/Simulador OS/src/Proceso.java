import java.util.ArrayList;
import java.util.List;

public class Proceso implements Runnable, Comparable<Proceso> {
    public enum Tipo {
        SISTEMA_OPERATIVO, USUARIO
    }

    public enum STATUS {
        RUNNING, BLOCKED, READY
    }

    private int id;
    private String nombre;
    private STATUS estado;
    private int pc;
    private int mar;
    private int numInstrucciones;
    private boolean cpuBound;
    private int ciclosExcepcion;
    private int ciclosSatisfaccionExcepcion;
    private int[] registros;
    private int tiempoLlegada;
    private Tipo tipo;
    private int prioridad;
    private int ciclosBloqueado; 
    private int ciclosEjecutados; 
    private int tiempoEnBloqueados; 

    public Proceso(int id, String nombre, STATUS estado, int pc, int numInstrucciones, boolean cpuBound, int ciclosExcepcion, int ciclosSatisfaccionExcepcion, int numRegistros) {
        this.id = id;
        this.nombre = nombre;
        this.estado = estado;
        this.pc = pc;
        this.mar = pc;
        this.numInstrucciones = numInstrucciones;
        this.cpuBound = cpuBound;
        this.ciclosExcepcion = ciclosExcepcion;
        this.ciclosSatisfaccionExcepcion = ciclosSatisfaccionExcepcion;
        this.registros = new int[numRegistros];
        for (int i = 0; i < numRegistros; i++) {
            this.registros[i] = (int) (Math.random() * 100); // Inicializa registros con valores aleatorios
        }
        this.tiempoLlegada = (int) (Math.random() * 100); // Inicializa tiempo de llegada con un valor aleatorio
        this.tipo = Tipo.USUARIO; // Por defecto
        this.prioridad = (int) (Math.random() * 5); // Inicializa prioridad con un valor aleatorio
        this.ciclosBloqueado = 0; // Inicializa en 0
        this.ciclosEjecutados = 0; // Inicializa en 0
    }

    public void incrementarTiempoEnBloqueados() {
        ciclosBloqueado++;
    }


    @Override
    public int compareTo(Proceso otro) {
        return Integer.compare(this.numInstrucciones, otro.numInstrucciones);
    }

    public int getTiempoRestante() {
        return numInstrucciones - pc;
    }

    public int getTiempoEnBloqueados() {
        return tiempoEnBloqueados;
    }

    public void resetTiempoEnBloqueados() {
        ciclosBloqueado = 0;
    }


    // Getters and Setters
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public STATUS getEstado() {
        return estado;
    }

    public void setEstado(STATUS estado) {
        this.estado = estado;
    }

    public int getPc() {
        return pc;
    }

    public void setPc(int nuevoPc) {
        this.pc = nuevoPc;
        this.mar = pc;
    }

    public void setMar(int mar) {
        this.mar = mar;
    }

    public int getMar() {
        return mar;
    }

    public int getNumInstrucciones() {
        return numInstrucciones;
    }

    public void setNumInstrucciones(int numInstrucciones) {
        this.numInstrucciones = numInstrucciones;
    }

    public boolean isCpuBound() {
        return cpuBound;
    }

    public void setCpuBound(boolean cpuBound) {
        this.cpuBound = cpuBound;
    }

    public int getCiclosExcepcion() {
        return ciclosExcepcion;
    }

    public void setCiclosExcepcion(int ciclosExcepcion) {
        this.ciclosExcepcion = ciclosExcepcion;
    }

    public int getCiclosSatisfaccionExcepcion() {
        return ciclosSatisfaccionExcepcion;
    }

    public void setCiclosSatisfaccionExcepcion(int ciclosSatisfaccionExcepcion) {
        this.ciclosSatisfaccionExcepcion = ciclosSatisfaccionExcepcion;
    }

    public int[] getRegistros() {
        return registros;
    }

    public void setRegistros(int[] registros) {
        this.registros = registros;
    }

    public Tipo getTipo() {
        return this.tipo;
    }

    public void setTipo(Tipo tipo) {
        this.tipo = tipo;
    }

    public int getTiempoLlegada() {
        return tiempoLlegada;
    }

    public void setTiempoLlegada(int tiempoLlegada) {
        this.tiempoLlegada = tiempoLlegada;
    }

    public int getPrioridad() {
        return prioridad;
    }

    public void setPrioridad(int prioridad) {
        this.prioridad = prioridad;
    }

    public int getCiclosBloqueado() {
        return ciclosBloqueado;
    }

    public boolean estaDesbloqueado() {
        return ciclosBloqueado >= ciclosSatisfaccionExcepcion;
    }

    public void incrementarCiclosEjecutados() {
        this.ciclosEjecutados++;
    }

    public boolean necesitaBloquearse() {
        return ciclosEjecutados >= ciclosExcepcion;
    }


    @Override
public void run() {
    // Simulación del proceso
    while (pc < numInstrucciones) {
        // Simular la ejecución de una instrucción
        pc++;
        try {
            Thread.sleep(100); // Simular el tiempo de ejecución de una instrucción
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }
    estado = STATUS.READY; // Cambiar el estado del proceso a READY cuando termina
}
    private Nodo frente;

    public List<Proceso> toList() {
        List<Proceso> list = new ArrayList<>();
        Nodo actual = frente;
        while (actual != null) {
            list.add(actual.getProceso());
            actual = actual.getSiguiente();
        }
        return list;
    }

    @Override
    public String toString() {
        StringBuilder registrosStr = new StringBuilder("[");
        for (int i = 0; i < registros.length; i++) {
            registrosStr.append(registros[i]);
            if (i < registros.length - 1) {
                registrosStr.append(", ");
            }
        }
        registrosStr.append("]");

        return "Proceso{" +
                "id=" + id +
                ", nombre='" + nombre + '\'' +
                ", estado=" + estado +
                ", pc=" + pc +
                ", mar=" + mar +
                ", numInstrucciones=" + numInstrucciones +
                ", cpuBound=" + cpuBound +
                ", ciclosExcepcion=" + ciclosExcepcion +
                ", ciclosSatisfaccionExcepcion=" + ciclosSatisfaccionExcepcion +
                ", registros=" + registrosStr.toString() +
                ", tiempoLlegada=" + tiempoLlegada +
                ", tipo=" + tipo +
                ", prioridad=" + prioridad +
                ", ciclosBloqueado=" + ciclosBloqueado +
                ", ciclosEjecutados=" + ciclosEjecutados +
                '}';
    }
}