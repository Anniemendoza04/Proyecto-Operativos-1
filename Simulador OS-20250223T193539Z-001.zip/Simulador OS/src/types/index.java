/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
import java.util.List;

public class index {
    public interface PerformanceData {
        long getTimestamp();
        double getCpuUsage();
        double getMemoryUsage();
    }

    public interface ProcessData {
        int getId();
        String getName();
        Proceso.STATUS getStatus();
        int getExecutionTime();
    }

    public interface SimulationConfig {
        int getNumProcessors();
        long getCycleDuration();
        Planificador.AlgoritmoPlanificacion getSchedulingAlgorithm();
    }

    public interface Graphable {
        void updateGraph(List<PerformanceData> data);
    }
}