# Code Citations

## License: unknown
https://github.com/adrianc68/GestionCurso/tree/a2ebf45acd7aad590864e09d14cfcfe798fbce62/src/domain/Tema.java

```
int id) {
        this.id = id;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public Estado getEstado() {
        return estado;
    }

    public void setEstado(Estado estado) {
        this
```


## License: unknown
https://github.com/miguelangelmanuttupaligas/CRUD-Adopcion/tree/b7bf00eac59fbb7ba8ab0dbd0ec3fd950acd4fd1/src/main/java/com/api/appdogapp/models/Estado.java

```
return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public Estado getEstado() {
        return estado;
    }

    public
```


## License: unknown
https://github.com/ccpinzon/AlgoritmoPrioridad/tree/81391e6ff427bcad87ed4ae131d2ea081796fc03/src/Logic/Proceso.java

```
int getTiempoLlegada() {
        return tiempoLlegada;
    }

    public void setTiempoLlegada(int tiempoLlegada) {
        this.tiempoLlegada = tiempoLlegada;
    }

    public int getPrioridad() {
        return prioridad;
    }

    public void setPrioridad(int prioridad) {
        this.prioridad = prioridad;
    }

    @Override
    public String toString(
```

