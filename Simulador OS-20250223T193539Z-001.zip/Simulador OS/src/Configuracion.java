import java.util.Map;

public class Configuracion {
    private String politicaPlanificacion;
    private int cantidadCpus;
    private int cantidadColasPrioridad;
    private Map<String, Object> parametrosPolitica; // Para parámetros específicos de cada política

    // Constructor, getters y setters
    public Configuracion() {
        // Constructor por defecto necesario para Gson
    }

    public Configuracion(String politicaPlanificacion, int cantidadCpus, int cantidadColasPrioridad, Map<String, Object> parametrosPolitica) {
        this.politicaPlanificacion = politicaPlanificacion;
        this.cantidadCpus = cantidadCpus;
        this.cantidadColasPrioridad = cantidadColasPrioridad;
        this.parametrosPolitica = parametrosPolitica;
    }

    public String getPoliticaPlanificacion() {
        return politicaPlanificacion;
    }

    public void setPoliticaPlanificacion(String politicaPlanificacion) {
        this.politicaPlanificacion = politicaPlanificacion;
    }

    public int getCantidadCpus() {
        return cantidadCpus;
    }

    public void setCantidadCpus(int cantidadCpus) {
        this.cantidadCpus = cantidadCpus;
    }

    public int getCantidadColasPrioridad() {
        return cantidadColasPrioridad;
    }

    public void setCantidadColasPrioridad(int cantidadColasPrioridad) {
        this.cantidadColasPrioridad = cantidadColasPrioridad;
    }

    public Map<String, Object> getParametrosPolitica() {
        return parametrosPolitica;
    }

    public void setParametrosPolitica(Map<String, Object> parametrosPolitica) {
        this.parametrosPolitica = parametrosPolitica;
    }
}