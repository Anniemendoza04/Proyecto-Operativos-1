import java.util.PriorityQueue;

public class Planificador {
    public enum AlgoritmoPlanificacion {
        FCFS, SJF, RoundRobin, SRT, Feedback
    }

    private AlgoritmoPlanificacion algoritmoActual;
    private int quantum; // Tiempo de quantum para Round Robin
    private SimuladorOS simulador;

    public Planificador(AlgoritmoPlanificacion algoritmoInicial, SimuladorOS simulador) {
        this.algoritmoActual = algoritmoInicial;
        this.quantum = 5; // Valor por defecto del quantum
        this.simulador = simulador;
    }

    public void cambiarAlgoritmo(AlgoritmoPlanificacion nuevoAlgoritmo) {
        this.algoritmoActual = nuevoAlgoritmo;
    }

    public AlgoritmoPlanificacion getAlgoritmoActual() {
        return algoritmoActual;
    }

    public void setQuantum(int quantum) {
        this.quantum = quantum;
    }

    public void planificar(Cola[] colasPrioridad, Cola colaListos, Cola colaBloqueados, Cola colaRunning, CPU[] cpus) {
        // Mover procesos desbloqueados de la cola de bloqueados a la cola de listos
        moverProcesosDesbloqueados(colaBloqueados, colaListos);

        switch (algoritmoActual) {
            case FCFS:
                planificarFCFS(colaListos, colaBloqueados, colaRunning, cpus);
                break;
            case SJF:
                planificarSJF(colaListos, colaBloqueados, colaRunning, cpus);
                break;
            case RoundRobin:
                planificarRoundRobin(colaListos, colaBloqueados, colaRunning, cpus);
                break;
            case SRT:
                planificarSRT(colaListos, colaBloqueados, colaRunning, cpus);
                break;
            case Feedback:
                planificarFeedback(colasPrioridad, colaBloqueados, colaRunning, cpus);
                break;
        }
    }

     private void moverProcesosDesbloqueados(Cola colaBloqueados, Cola colaListos) {
        Nodo actual = colaBloqueados.getFrente();
        Nodo anterior = null;
    
        while (actual != null) {
            Proceso proceso = actual.getProceso();
            if (proceso.estaDesbloqueado()) {
                if (anterior == null) {
                    colaBloqueados.setFrente(actual.getSiguiente());
                } else {
                    anterior.setSiguiente(actual.getSiguiente());
                }
                proceso.resetTiempoEnBloqueados();
                colaListos.encolar(proceso);
            } else {
                proceso.incrementarTiempoEnBloqueados();
                if (proceso.getTiempoEnBloqueados() > 10) { // Ajusta el umbral según sea necesario
                    proceso.setPrioridad(Math.max(proceso.getPrioridad() - 1, 0)); // Aumenta la prioridad
                }
                anterior = actual;
            }
            actual = actual.getSiguiente();
        }
    }

        private void planificarFCFS(Cola colaListos, Cola colaBloqueados, Cola colaRunning, CPU[] cpus) {
            for (CPU cpu : cpus) {
                if (cpu.getProcesoEjecutando() == null && !colaListos.estaVacia()) {
                    Proceso proceso = colaListos.desencolar();
                    cpu.setProcesoEjecutando(proceso);
                    proceso.setEstado(Proceso.STATUS.RUNNING);
                    colaRunning.encolar(proceso); // Añadir el proceso a la cola de running
                    System.out.println("Proceso " + proceso.getNombre() + " movido a RUNNING");
                }
        
                if (cpu.getProcesoEjecutando() != null) {
                    cpu.incrementarCiclos();
                    Proceso proceso = cpu.getProcesoEjecutando();
                    proceso.incrementarCiclosEjecutados();
                    proceso.setPc(proceso.getPc() + 1); // Incrementa el contador de programa
        
                    if (proceso.getPc() >= proceso.getNumInstrucciones()) {
                        proceso.setEstado(Proceso.STATUS.READY);
                        cpu.setProcesoEjecutando(null);
                        colaRunning.desencolar(); // Eliminar el proceso de la cola de running
                        colaListos.encolar(proceso); // Mover el proceso a la cola de listos
                        System.out.println("Proceso " + proceso.getNombre() + " completado y movido a READY");
                    } else if (proceso.necesitaBloquearse()) {
                        proceso.setEstado(Proceso.STATUS.BLOCKED);
                        colaRunning.desencolar(); // Eliminar el proceso de la cola de running
                        colaBloqueados.encolar(proceso);
                        cpu.setProcesoEjecutando(null);
                        System.out.println("Proceso " + proceso.getNombre() + " movido a BLOCKED");
                    }
                }
            }
        }
    
    private void planificarSJF(Cola colaListos, Cola colaBloqueados, Cola colaRunning, CPU[] cpus) {
        for (CPU cpu : cpus) {
            if (cpu.getProcesoEjecutando() == null && !colaListos.estaVacia()) {
                Proceso procesoMasCorto = null;
                Nodo nodoAnterior = null;
                Nodo nodoActual = colaListos.getFrente();
                Nodo nodoMasCorto = null;
    
                // Encontrar el shortest job
                while (nodoActual != null) {
                    Proceso procesoActual = nodoActual.getProceso();
                    if (procesoMasCorto == null || procesoActual.getNumInstrucciones() < procesoMasCorto.getNumInstrucciones()) {
                        procesoMasCorto = procesoActual;
                        nodoMasCorto = nodoAnterior;
                    }
                    nodoAnterior = nodoActual;
                    nodoActual = nodoActual.getSiguiente();
                }
    
                // Desencolar el proceso más corto
                if (nodoMasCorto == null) {
                    colaListos.setFrente(colaListos.getFrente().getSiguiente());
                } else {
                    nodoMasCorto.setSiguiente(nodoMasCorto.getSiguiente().getSiguiente());
                }
    
                cpu.setProcesoEjecutando(procesoMasCorto);
                cpu.setCiclosEjecucionCPU(0);
                procesoMasCorto.setEstado(Proceso.STATUS.RUNNING);
                colaRunning.encolar(procesoMasCorto); // Añadir el proceso a la cola de running
            }
    
            if (cpu.getProcesoEjecutando() != null) {
                cpu.incrementarCiclos();
                Proceso proceso = cpu.getProcesoEjecutando();
                proceso.incrementarCiclosEjecutados();
                proceso.setPc(proceso.getPc() + 1); // Incrementa el contador de programa
    
                if (proceso.getPc() >= proceso.getNumInstrucciones()) {
                    proceso.setEstado(Proceso.STATUS.READY);
                    cpu.setProcesoEjecutando(null);
                    colaRunning.desencolar(); // Eliminar el proceso de la cola de running
                    colaListos.encolar(proceso);
                } else if (proceso.necesitaBloquearse()) {
                    simulador.manejarExcepcionES(proceso);
                    colaRunning.desencolar(); // Eliminar el proceso de la cola de running
                    cpu.setProcesoEjecutando(null);
                }
            }
        }
    }
    
    private void planificarRoundRobin(Cola colaListos, Cola colaBloqueados, Cola colaRunning, CPU[] cpus) {
        for (CPU cpu : cpus) {
            if (cpu.getProcesoEjecutando() == null || cpu.getCiclosEjecucionCPU() >= quantum) {
                if (cpu.getProcesoEjecutando() != null) {
                    if (cpu.getProcesoEjecutando().getPc() < cpu.getProcesoEjecutando().getNumInstrucciones()) {
                        colaListos.encolar(cpu.getProcesoEjecutando());
                    }
                    colaRunning.desencolar(); // Eliminar el proceso de la cola de running
                }
                if (!colaListos.estaVacia()) {
                    Proceso siguienteProceso = colaListos.desencolar();
                    cpu.setProcesoEjecutando(siguienteProceso);
                    cpu.setCiclosEjecucionCPU(0);
                    siguienteProceso.setEstado(Proceso.STATUS.RUNNING);
                    colaRunning.encolar(siguienteProceso); // Añadir el proceso a la cola de running
                }
            }
    
            if (cpu.getProcesoEjecutando() != null) {
                cpu.incrementarCiclos();
                Proceso proceso = cpu.getProcesoEjecutando();
                proceso.incrementarCiclosEjecutados();
                proceso.setPc(proceso.getPc() + 1); // Incrementa el contador de programa
    
                if (proceso.getPc() >= proceso.getNumInstrucciones()) {
                    proceso.setEstado(Proceso.STATUS.READY);
                    cpu.setProcesoEjecutando(null);
                    colaRunning.desencolar(); // Eliminar el proceso de la cola de running
                    colaListos.encolar(proceso);
                } else if (proceso.necesitaBloquearse()) {
                    simulador.manejarExcepcionES(proceso);
                    colaRunning.desencolar(); // Eliminar el proceso de la cola de running
                    cpu.setProcesoEjecutando(null);
                }
            }
        }
    }
    private void planificarSRT(Cola colaListos, Cola colaBloqueados, Cola colaRunning, CPU[] cpus) {
        for (CPU cpu : cpus) {
            if (cpu.getProcesoEjecutando() == null && !colaListos.estaVacia()) {
                Proceso procesoMasCorto = null;
                Nodo nodoAnterior = null;
                Nodo nodoActual = colaListos.getFrente();
                Nodo nodoMasCorto = null;
    
                // Encontrar el proceso con el menor tiempo de ejecución restante
                while (nodoActual != null) {
                    Proceso procesoActual = nodoActual.getProceso();
                    int tiempoRestante = procesoActual.getNumInstrucciones() - procesoActual.getPc();
                    if (procesoMasCorto == null || tiempoRestante < (procesoMasCorto.getNumInstrucciones() - procesoMasCorto.getPc())) {
                        procesoMasCorto = procesoActual;
                        nodoMasCorto = nodoAnterior;
                    }
                    nodoAnterior = nodoActual;
                    nodoActual = nodoActual.getSiguiente();
                }
    
                // Desencolar el proceso más corto
                if (nodoMasCorto == null) {
                    colaListos.setFrente(colaListos.getFrente().getSiguiente());
                } else {
                    nodoMasCorto.setSiguiente(nodoMasCorto.getSiguiente().getSiguiente());
                }
    
                cpu.setProcesoEjecutando(procesoMasCorto);
                cpu.setCiclosEjecucionCPU(0);
                procesoMasCorto.setEstado(Proceso.STATUS.RUNNING);
                colaRunning.encolar(procesoMasCorto); // Añadir el proceso a la cola de running
            } else if (cpu.getProcesoEjecutando() != null) {
                // Verificar si hay un proceso en la cola con menor tiempo de ejecución restante
                Proceso procesoActual = cpu.getProcesoEjecutando();
                int tiempoRestanteActual = procesoActual.getNumInstrucciones() - procesoActual.getPc();
                Nodo nodoAnterior = null;
                Nodo nodoActual = colaListos.getFrente();
                Nodo nodoMasCorto = null;
                Proceso procesoMasCorto = null;
    
                while (nodoActual != null) {
                    Proceso procesoEnCola = nodoActual.getProceso();
                    int tiempoRestanteEnCola = procesoEnCola.getNumInstrucciones() - procesoEnCola.getPc();
                    if (tiempoRestanteEnCola < tiempoRestanteActual) {
                        procesoMasCorto = procesoEnCola;
                        nodoMasCorto = nodoAnterior;
                        tiempoRestanteActual = tiempoRestanteEnCola;
                    }
                    nodoAnterior = nodoActual;
                    nodoActual = nodoActual.getSiguiente();
                }
    
                // Si se encuentra un proceso con menor tiempo de ejecución restante, interrumpir el proceso actual
                if (procesoMasCorto != null) {
                    colaListos.encolar(cpu.getProcesoEjecutando());
                    colaRunning.desencolar(); // Eliminar el proceso de la cola de running
                    if (nodoMasCorto == null) {
                        colaListos.setFrente(colaListos.getFrente().getSiguiente());
                    } else {
                        nodoMasCorto.setSiguiente(nodoMasCorto.getSiguiente().getSiguiente());
                    }
                    cpu.setProcesoEjecutando(procesoMasCorto);
                    cpu.setCiclosEjecucionCPU(0);
                    colaRunning.encolar(procesoMasCorto); // Añadir el proceso a la cola de running
                }
            }
    
            if (cpu.getProcesoEjecutando() != null) {
                cpu.incrementarCiclos();
                Proceso proceso = cpu.getProcesoEjecutando();
                proceso.incrementarCiclosEjecutados();
                proceso.setPc(proceso.getPc() + 1); // Incrementa el contador de programa
    
                if (proceso.getPc() >= proceso.getNumInstrucciones()) {
                    proceso.setEstado(Proceso.STATUS.READY);
                    cpu.setProcesoEjecutando(null);
                    colaRunning.desencolar(); // Eliminar el proceso de la cola de running
                    colaListos.encolar(proceso);
                } else if (proceso.necesitaBloquearse()) {
                    simulador.manejarExcepcionES(proceso);
                    colaRunning.desencolar(); // Eliminar el proceso de la cola de running
                    cpu.setProcesoEjecutando(null);
                }
            }
        }
    }
    
    private void planificarFeedback(Cola[] colasPrioridad, Cola colaBloqueados, Cola colaRunning, CPU[] cpus) {
        for (CPU cpu : cpus) {
            if (cpu.getProcesoEjecutando() == null) {
                // Buscar el primer proceso en las colas de mayor a menor prioridad
                for (int i = 0; i < colasPrioridad.length; i++) {
                    if (!colasPrioridad[i].estaVacia()) {
                        Proceso siguienteProceso = colasPrioridad[i].desencolar();
                        cpu.setProcesoEjecutando(siguienteProceso);
                        cpu.setCiclosEjecucionCPU(0);
                        siguienteProceso.setEstado(Proceso.STATUS.RUNNING);
                        colaRunning.encolar(siguienteProceso); // Añadir el proceso a la cola de running
                        break;
                    }
                }
            } else {
                // Incrementar el contador de ciclos de ejecución del proceso actual
                cpu.incrementarCiclos();
                Proceso proceso = cpu.getProcesoEjecutando();
                proceso.incrementarCiclosEjecutados();
                proceso.setPc(proceso.getPc() + 1); // Incrementa el contador de programa
    
                // Mover el proceso a una cola de menor prioridad si ha utilizado su quantum
                int prioridadActual = proceso.getPrioridad();
                if (cpu.getCiclosEjecucionCPU() >= quantum) {
                    if (prioridadActual < colasPrioridad.length - 1) {
                        colasPrioridad[prioridadActual + 1].encolar(proceso);
                    } else {
                        colasPrioridad[prioridadActual].encolar(proceso);
                    }
                    colaRunning.desencolar(); // Eliminar el proceso de la cola de running
                    cpu.setProcesoEjecutando(null);
                }
    
                if (proceso.getPc() >= proceso.getNumInstrucciones()) {
                    proceso.setEstado(Proceso.STATUS.READY);
                    colaRunning.desencolar(); // Eliminar el proceso de la cola de running
                    cpu.setProcesoEjecutando(null);
                    colasPrioridad[proceso.getPrioridad()].encolar(proceso);
                } else if (proceso.necesitaBloquearse()) {
                    simulador.manejarExcepcionES(proceso);
                    colaRunning.desencolar(); // Eliminar el proceso de la cola de running
                    cpu.setProcesoEjecutando(null);
                }
            }
        }
    }
}