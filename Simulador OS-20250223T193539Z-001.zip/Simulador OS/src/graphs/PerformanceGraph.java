/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package graphs;

/**
 *
 * @author annie
 */


import javax.swing.*;
import java.awt.*;
import java.awt.geom.Line2D;
import java.util.ArrayList;
import java.util.List;

public class PerformanceGraph extends JPanel {
    private List<Double> performanceData;
    private double maxValue;

    public PerformanceGraph() {
        this.performanceData = new ArrayList<>();
        this.maxValue = 100.0; // Default max value for scaling
    }

    public void addPerformanceData(double value) {
        performanceData.add(value);
        if (value > maxValue) {
            maxValue = value;
        }
        repaint();
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        Graphics2D g2d = (Graphics2D) g;

        int width = getWidth();
        int height = getHeight();
        int padding = 20;

        // Draw axes
        g2d.drawLine(padding, height - padding, padding, padding);
        g2d.drawLine(padding, height - padding, width - padding, height - padding);

        // Draw performance graph
        if (performanceData.size() > 1) {
            for (int i = 1; i < performanceData.size(); i++) {
                double x1 = padding + (width - 2 * padding) * (i - 1) / (performanceData.size() - 1);
                double y1 = height - padding - (height - 2 * padding) * (performanceData.get(i - 1) / maxValue);
                double x2 = padding + (width - 2 * padding) * i / (performanceData.size() - 1);
                double y2 = height - padding - (height - 2 * padding) * (performanceData.get(i) / maxValue);
                g2d.draw(new Line2D.Double(x1, y1, x2, y2));
            }
        }
    }

    public void resetGraph() {
        performanceData.clear();
        maxValue = 100.0; // Reset max value
        repaint();
    }

    public void updateData(List<Double> performanceData) {
        this.performanceData = performanceData;
        if (!performanceData.isEmpty()) {
            maxValue = performanceData.stream().max(Double::compare).get();
        } else {
            maxValue = 100.0;
        }
        repaint();
    }
}