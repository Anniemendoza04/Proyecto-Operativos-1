/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author annie
 */

import javax.swing.*;
import javax.swing.border.Border;
import javax.swing.border.LineBorder;
import java.awt.*;

class ProcesoListCellRenderer extends DefaultListCellRenderer {
    private Border border = new LineBorder(Color.BLACK, 1); // Borde negro de 1 píxel

    @Override
    public Component getListCellRendererComponent(JList<?> list, Object value, int index, boolean isSelected, boolean cellHasFocus) {
        if (value instanceof Proceso) {
            Proceso proceso = (Proceso) value;
            String texto = String.format("<html>" +
                    "ID: %d<br>" +
                    "Nombre: %s<br>" +
                    "Estado: %s<br>" +
                    "PC: %d<br>" +
                    "Instrucciones: %d<br>" +
                    "Prioridad: %d" +
                    "</html>",
                    proceso.getId(),
                    proceso.getNombre(),
                    proceso.getEstado(),
                    proceso.getPc(),
                    proceso.getNumInstrucciones(),
                    proceso.getPrioridad());

            JLabel label = (JLabel) super.getListCellRendererComponent(list, texto, index, isSelected, cellHasFocus);
            label.setBorder(border); // Añadir el borde al JLabel
            return label;
        }
        return super.getListCellRendererComponent(list, value, index, isSelected, cellHasFocus);
    }
}